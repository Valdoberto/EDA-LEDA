package sorting.simpleSorting;

import sorting.AbstractSorting;

/**
 * The selection sort algorithm chooses the smallest element from the array and
 * puts it in the first position. Then chooses the second smallest element and
 * stores it in the second position, and so on until the array is sorted.
 */
public class SelectionSort<T extends Comparable<T>> extends AbstractSorting<T> {

	@Override
	public void sort(T[] array, int leftIndex, int rightIndex) {
		int j = 0;
		while (j < rightIndex) {
			int menor = array[j];
			for(i = j + 1; i < array.length; i ++){
				if (array[i] < menor){
					menor = array[i];
				}
			}
			swap(array, array[j] , menor);
			j++;
		}
	}
}
